﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TestAssignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        BindingManagerBase managerBase;

        String constr = @"Data Source=VIDYANAND;Initial Catalog=TestDb;Integrated Security=True";
      
        private void TextBox2_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            if (txtEmail.Text.Length > 0)
            {
                if (!rEmail.IsMatch(txtEmail.Text))
                {
                    MessageBox.Show("Invalid Email", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.SelectAll();
                    e.Cancel = true;
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (txtpass.Text == "" || txtConf_pass.Text == "")
            {
                MessageBox.Show("Please enter values");
                return;
            }
            if (txtConf_pass.Text != txtpass.Text)
            {
                MessageBox.Show("confirm password not matching with new passsword");
                txtConf_pass.Focus();
                return;
            }
       
          SqlConnection con = new SqlConnection(constr);
            con.Open();
            if (txtEmpId.Text == "" || txtname.Text == "" || txtEmail.Text == "" || txtpass.Text == "")
            {
                MessageBox.Show("Please enter a values");
            }
            else
            {
                string query = "Insert into test(EmpId,Name,Gender,Position,Email,Password) values(@EmpId,@Name,@Gender,@Position,@Email,@Password)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@EmpId", txtEmpId.Text);
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                //cmd.Parameters.AddWithValue("@DOB", dob.Text);
                cmd.Parameters.AddWithValue("@Gender", cmbgender.Text);
                cmd.Parameters.AddWithValue("@Position", cmbposition.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Password", txtpass.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data has been success fully inserted");
                txtEmpId.Text = "";
                txtname.Text = "";
                txtEmail.Text = "";
                txtpass.Text = "";
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            var LoginForm = new  LoginForm();

            LoginForm.Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            if (txtEmpId.Text == "" || txtname.Text == "" || txtEmail.Text == "" || txtpass.Text == ""|| txtConf_pass.Text == "")
            {
                MessageBox.Show("Data has been NOt updated");
            }
            else
            {

                string query = "update test set Name=@Name,Gender=@Gender,Position=@Position,Email=@Email,Password=@Password Where EmpId=@EmpId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@EmpId", txtEmpId.Text);
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@Gender", cmbgender.Text);
                cmd.Parameters.AddWithValue("@Position", cmbposition.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Password", txtpass.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data has been successfully Updated");
              
            }
        }

        

        private void Button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    SqlConnection con = new SqlConnection(@"Data Source=VIDYANAND;Initial Catalog=TestDb;Integrated Security=True");
        //    con.Open();
        //    string query = "select * from test";
        //    SqlDataAdapter SDA = new SqlDataAdapter(query, con);
        //    DataTable dt = new DataTable();
        //    SDA.Fill(dt);
        //    dataGridView1.DataSource = dt;
        //    // dataGridView1.DataBind();
        //    con.Close();

        //}

      

        private void Button6_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=VIDYANAND;Initial Catalog=TestDb;Integrated Security=True");
            con.Open();
            string query = "select * from test";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            SDA.Fill(dt);
            dataGridView1.DataSource = dt;
            // dataGridView1.DataBind();
            //txtEmpId.DataBindings.Add("text", dt, "EmpId");
            //txtname.DataBindings.Add("text", dt, "Name");
            //cmbgender.DataBindings.Add("text", dt, "Gender");
            //cmbposition.DataBindings.Add("text", dt, "Position");
            //txtEmail.DataBindings.Add("text", dt, "Email");
            //txtpass.DataBindings.Add("text", dt, "Password");
            //con.Close();
           
            managerBase = this.BindingContext[dt];

        }

        private void DataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtEmpId.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            cmbgender.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            cmbposition.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtEmail.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtpass.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            if (txtEmpId.Text== "" || txtname.Text == "" || txtEmail.Text == "" || txtpass.Text == "")
            {
                MessageBox.Show("Data has been NOt Deleted");
            }
            else
            {

                string query = "Delete from test Where EmpId=@EmpId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@EmpId", txtEmpId.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data has been Deleted");
            }

        }

        private void Button7_Click(object sender, EventArgs e)
        {
            managerBase.Position += 1;
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            managerBase.Position -= 1;
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            managerBase.Position = managerBase.Count;
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            txtEmpId.Text = "";
            txtname.Text = "";
            txtEmail.Text = "";
            txtpass.Text = "";
            txtConf_pass.Text = "";
        }
    }
}