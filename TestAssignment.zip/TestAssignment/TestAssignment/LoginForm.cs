﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TestAssignment
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void Login_Click(object sender, EventArgs e)
        {
             
                //Connection String   
                SqlConnection con = new SqlConnection(@"Data Source=VIDYANAND;Initial Catalog=TestDb;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select * from test where Email=@UserName and Password =@Password", con);
                cmd.Parameters.AddWithValue("@UserName", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Password", txtpass.Text);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                //Connection open here   
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Successfully loged in");
                    //after successful it will redirect  to next page .  
                    Form1 f1 = new Form1();
                     f1.Show();
                }
                else
                {
                    MessageBox.Show("Please enter Correct Username and Password");
                }
            }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    

}
